HTTP proxy over SOCK5
=====================

# Install

`go get github.com/icexin/sockhttp`

# Usage

see `sockhttp -h`
